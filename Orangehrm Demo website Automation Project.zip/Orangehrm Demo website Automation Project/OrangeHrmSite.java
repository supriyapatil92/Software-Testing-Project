package pjct_flow;

import org.openqa.selenium.By;




import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class OrangeHrmSite
{

	public static void main(String[] args)
	{
        
		//Open Chrome browser              //TestCase_1          
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Dell\\Desktop\\Selenium Jar Files\\chromedriver.exe");
		WebDriver w=new ChromeDriver();
		
		//Open Url                                    
		w.get("https://opensource-demo.orangehrmlive.com/");   
		
		//OrangeHrm site invalid login credentials       //TestCase_2
		w.findElement(By.id("txtUsername")).sendKeys("Admin");
		w.findElement(By.id("txtPassword")).sendKeys("admin13");
		w.findElement(By.id("btnLogin")).click();         
		w.findElement(By.linkText("Forgot your password?")).click();     //TestCase_3   
		w.findElement(By.id("securityAuthentication_userName")).sendKeys("admin123");    
		/*w.findElement(By.id("btnSearchValues")).click(); */      //Reset Password button_TestCase_4
		w.findElement(By.id("btnCancel")).click();        //TestCase_5
		
				
		//OrangeHrm site valid login credentials_TestCase_6
		w.findElement(By.id("txtUsername")).sendKeys("Admin");
		w.findElement(By.id("txtPassword")).sendKeys("admin123");
		w.findElement(By.id("btnLogin")).click();    //valid credentials 
		
		
		//With Mousehover Handling
		Actions a=new Actions(w);  
		
		//In Admin Section
		//In User Management Section
		//Users
		a.moveToElement(w.findElement(By.linkText("Admin"))).build().perform();
		a.moveToElement(w.findElement(By.linkText("User Management"))).build().perform();
        w.findElement(By.linkText("Users")).click();
		w.findElement(By.id("btnAdd")).click();   //TestCase_7
		//dropdown menu_user role_TestCase_8
		Select f1=new Select(w.findElement(By.id("systemUser_userType")));
		f1.selectByValue("1");
		w.findElement(By.id("systemUser_employeeName_empName")).sendKeys("Odis Adalwin");
		w.findElement(By.id("systemUser_userName")).sendKeys("mineipm");
		//dropdown menu_status_TestCase_9
		Select f2=new Select(w.findElement(By.id("systemUser_userType")));
		f2.selectByValue("1");
		w.findElement(By.id("systemUser_password")).sendKeys("Pett@777");
		w.findElement(By.id("systemUser_confirmPassword")).sendKeys("Pett@777");
		w.findElement(By.id("btnSave")).click();       //TestCase_10    
		/*w.findElement(By.id("btnCancel")).click();*/     //TestCase_11
		/*w.findElement(By.id("searchBtn")).click();*/     //TestCase_12
		/*w.findElement(By.id("resetBtn")).click();*/      //TestCase_13
		
		
		
		//In Job Section 
		//Job titles
		a.moveToElement(w.findElement(By.linkText("Job"))).build().perform();
		w.findElement(By.linkText("Job Titles")).click();
		
		w.findElement(By.id("btnAdd")).click();   //TestCase_14
		w.findElement(By.id("jobTitle_jobTitle")).sendKeys("Test Engineer100");
		w.findElement(By.id("jobTitle_jobDescription")).sendKeys("Software testing is the process of evaluating and verifying that a software product or application does what it is supposed to do.");
		w.findElement(By.id("jobTitle_note")).sendKeys("Dear Hiring Manager, I am submitting my resume for the position of Software Tester.");
		w.findElement(By.id("btnSave")).click();    //TestCase_15
		/*w.findElement(By.id("btnCancel")).click();*/  //TestCase_16
		/*w.findElement(By.id("btnDelete")).click();*/  //TestCase_17
		
		//Pay Grades
		a.moveToElement(w.findElement(By.linkText("Job"))).build().perform();
		w.findElement(By.linkText("Pay Grades")).click();
		
		w.findElement(By.id("btnAdd")).click();  //TestCase_18
		w.findElement(By.id("payGrade_name")).sendKeys("Grade 89.");
		w.findElement(By.id("btnSave")).click();   //TestCase_19
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDelete")).click();*/
		
		//Employment Status
		a.moveToElement(w.findElement(By.linkText("Job"))).build().perform();
		w.findElement(By.linkText("Employment Status")).click();
		
		w.findElement(By.id("btnAdd")).click();  //TestCase_20
		w.findElement(By.id("empStatus_name")).sendKeys("Full-Time Permanent100");
		w.findElement(By.id("btnSave")).click();   //TestCase_21
		//w.findElement(By.id("ohrmList_chkSelectRecord_8")).click();
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDelete")).click();*/
		
		
		//Job Categories
        a.moveToElement(w.findElement(By.linkText("Job"))).build().perform();
		w.findElement(By.linkText("Job Categories")).click();
		
		w.findElement(By.id("btnAdd")).click();  //TestCase_22
		w.findElement(By.id("jobCategory_name")).sendKeys("Software Test Engineer100");
		w.findElement(By.id("btnSave")).click();  //TestCase_23
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDelete")).click();*/
		
		
		//Work Shifts
		a.moveToElement(w.findElement(By.linkText("Job"))).build().perform();
		w.findElement(By.linkText("Work Shifts")).click();
		
		w.findElement(By.id("btnAdd")).click();  //TestCase_24
		w.findElement(By.id("workShift_name")).sendKeys("Max9");
		//dropdown menu_Work Hours: From //TestCase_25
		Select f3=new Select(w.findElement(By.id("workShift_workHours_from")));
		f3.selectByValue("08:00");
		//dropdown menu_Work Hours: To //TestCase_26
		Select f4=new Select(w.findElement(By.id("workShift_workHours_to")));
		f4.selectByValue("16:00");
		//dropdown menu_Available Employees //TestCase_27
		Select f5=new Select(w.findElement(By.id("workShift_availableEmp")));
		f5.selectByValue("5");   //Defect_01
		w.findElement(By.id("btnAssignEmployee")).click(); //Assigned Employees
		w.findElement(By.id("btnSave")).click();  //TestCase_28
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDelete")).click();*/
		
		
		//In Organization Section
		//General Information
		a.moveToElement(w.findElement(By.linkText("Organization"))).build().perform();
        w.findElement(By.linkText("General Information")).click();
		w.findElement(By.id("btnSaveGenInfo")).click();    //Edit button_TestCase_29
		w.findElement(By.id("organization_name")).sendKeys("OrangeHRM");
		w.findElement(By.id("btnSaveGenInfo")).click();    //Save button_TestCase_30   
		
		//Locations
		a.moveToElement(w.findElement(By.linkText("Organization"))).build().perform();
        w.findElement(By.linkText("Locations")).click();
        w.findElement(By.id("btnAdd")).click();  //TestCase_31
        w.findElement(By.id("location_name")).sendKeys("Canadian Regional HQ8");
        //dropdowm menu_Country_TestCase_32
        Select f6=new Select(w.findElement(By.id("location_country")));
		f6.selectByValue("AU");
		w.findElement(By.id("btnSave")).click();  //TestCase_33
		/*w.findElement(By.id("btnCancel")).click();*/    //TestCase_34
		/*w.findElement(By.id("btnSearch")).click();*/    //TestCase_35
		/*w.findElement(By.id("btnReset")).click();*/     //TestCase_36
		
		//Structure
		a.moveToElement(w.findElement(By.linkText("Organization"))).build().perform();
        w.findElement(By.linkText("Structure")).click();
        w.findElement(By.id("btnEdit")).click();     //Edit button_TestCase_37
        w.findElement(By.id("treeLink_addChild_2")).click();   //TestCase_38
        w.findElement(By.id("btnCancel")).click();   
        w.findElement(By.id("treeLink_delete_2")).click();    //TestCase_39
        w.findElement(By.id("dialogNo")).click();
        w.findElement(By.id("btnEdit")).click();    //TestCase_40    //Done button_Defect_02
        
        
        
        //In Qualifications Section
        //Skills
        a.moveToElement(w.findElement(By.linkText("Qualifications"))).build().perform();
		w.findElement(By.linkText("Skills")).click();
		
		w.findElement(By.id("btnAdd")).click();   //TestCase_41
		w.findElement(By.id("skill_name")).sendKeys("Core Java lang.");
		w.findElement(By.id("skill_description")).sendKeys("Programming Language");
		w.findElement(By.id("btnSave")).click();    //TestCase_42
		/*w.findElement(By.id("btnCancel")).click();*/    //TestCase_43
		/*w.findElement(By.id("btnDel")).click();*/       //TestCase_44
		
		
		//Education
		a.moveToElement(w.findElement(By.linkText("Qualifications"))).build().perform();
        w.findElement(By.linkText("Education")).click();
		w.findElement(By.id("btnAdd")).click();    //TestCase_45
		w.findElement(By.id("education_name")).sendKeys("Graduation91");
		w.findElement(By.id("btnSave")).click();   //TestCase_46
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDel")).click();*/
		
		
		//Licenses
		a.moveToElement(w.findElement(By.linkText("Qualifications"))).build().perform();
        w.findElement(By.linkText("Licenses")).click();
		w.findElement(By.id("btnAdd")).click();   //TestCase_47
		w.findElement(By.id("license_name")).sendKeys("Amazon Web Services(AWS)");
		w.findElement(By.id("btnSave")).click();    //TestCase_48
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDel")).click();*/
		
		
		//Languages
		a.moveToElement(w.findElement(By.linkText("Qualifications"))).build().perform();
        w.findElement(By.linkText("Languages")).click();
		w.findElement(By.id("btnAdd")).click();   //TestCase_49
		w.findElement(By.id("language_name")).sendKeys("English4.");
		w.findElement(By.id("btnSave")).click();   //TestCase_50
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDel")).click();*/
		
		
		//Memberships
		a.moveToElement(w.findElement(By.linkText("Qualifications"))).build().perform();
        w.findElement(By.linkText("Memberships")).click();
		w.findElement(By.id("btnAdd")).click();  //TestCase_51
		w.findElement(By.id("membership_name")).sendKeys("ISTQB10.");
		w.findElement(By.id("btnSave")).click();  //TestCase_52
		/*w.findElement(By.id("btnCancel")).click();*/  
		/*w.findElement(By.id("btnDelete")).click();*/  
		
		
		//Without Mousehover Handling
		//In Admin section 
		//Nationalities
		w.findElement(By.id("menu_admin_viewAdminModule")).click();
		   
		w.findElement(By.id("menu_admin_nationality")).click();
		w.findElement(By.id("btnAdd")).click(); //TestCase_53
		w.findElement(By.id("nationality_name")).sendKeys("Indian99.");
		w.findElement(By.id("btnSave")).click();  //TestCase_54
		/*w.findElement(By.id("btnCancel")).click();*/
		/*w.findElement(By.id("btnDelete")).click();*/
		
		
		//In Admin Section
		//In Recruitment Section
		//Candidates
	    w.findElement(By.id("menu_admin_viewAdminModule")).click();
		   
		w.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
		w.findElement(By.id("menu_recruitment_viewCandidates")).click();
		w.findElement(By.id("btnAdd")).click(); //TestCase_55
		w.findElement(By.id("addCandidate_firstName")).sendKeys("Supriya");
		w.findElement(By.id("addCandidate_lastName")).sendKeys("Patil");
		w.findElement(By.id("addCandidate_email")).sendKeys("supriya01@gmail.com");
		w.findElement(By.id("btnSave")).click();  //TestCase_56
		/*w.findElement(By.id("btnDelete")).click();*/
		/*w.findElement(By.id("btnSrch")).click();*/
		/*w.findElement(By.id("btnRst")).click();*/
		
		
		//In Recuritment Section
		//Vacancies
		w.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
		w.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
		w.findElement(By.id("btnAdd")).click(); //TestCase_57
		//dropdown menu_Job Title_TestCase_58
		Select f7=new Select(w.findElement(By.id("addJobVacancy_jobTitle")));
		f7.selectByValue("9");
		w.findElement(By.id("addJobVacancy_name")).sendKeys("IT Consultant11");
		w.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("Odis Adalwin");
		w.findElement(By.id("btnSave")).click(); //TestCase_59
		w.findElement(By.id("btnBack")).click(); //TestCase_60
		/*w.findElement(By.id("btnDelete")).click();*/
		/*w.findElement(By.id("btnSrch")).click();*/
		/*w.findElement(By.id("btnRst")).click();*/
		
	    //Close Current window    
		w.close(); 

	}

}
